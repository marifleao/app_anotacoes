import 'package:app_anotacoes/controllers/listar_notas_controller.dart';
import 'package:app_anotacoes/models/anotacao.dart';
import 'package:flutter/material.dart';
import 'package:app_anotacoes/controllers/controllers.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:get_it/get_it.dart';

class NovaAnotacaoPage extends StatefulWidget {
  final ListarNotasController controller;
  const NovaAnotacaoPage({super.key, required this.controller});

  @override
  State<NovaAnotacaoPage> createState() => _NovaAnotacaoPageState();
}

class _NovaAnotacaoPageState extends State<NovaAnotacaoPage> {
  //final controllerLista = ListarNotasController();
  // final _form = GlobalKey<FormState>();
  // final _titulo = TextEditingController();
  // final _descricao = TextEditingController();
  // final _status = TextEditingController();

  // salvarAnotacao() {
  //   if (_form.currentState!.validate()) {
  //     Anotacao2 novaAnotacao = Anotacao2(
  //       titulo: _titulo.text,
  //       descricao: _descricao.text,
  //       status: _status.text,
  //     );
  //     Navigator.pop(context, novaAnotacao);

  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(
  //         content: Text("Anotação salva com sucesso!"),
  //       ),
  //     );
  //   }
  // }

  //final controller = GerenciaAnotacao();

  // _textField({String? labelText, onChanged}) {
  //   return TextField(
  //     onChanged: onChanged,
  //     decoration: InputDecoration(
  //       labelText: labelText,
  //       border: const OutlineInputBorder(),
  //       prefixIcon: const Icon(Icons.label_important_outline),
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    // String titulo = '';
    // String descricao = '';
    // String status = '';
    //final controller = GetIt.I.get<GerenciaAnotacao>();
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "Criar anotação",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 169, 149, 204),
        leading: const BackButton(
          color: Colors.white,
        ),
      ),
      body: Observer(builder: (_) {
        return Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            const SizedBox(
              height: 10,
            ),
            TextField(
              decoration: const InputDecoration(
                labelText: 'Título',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.label_important_outline),
              ),
              onChanged: (value) {
                widget.controller.campoTitulo = value;
              },
            ),
            const SizedBox(
              height: 20,
            ),
            TextField(
              decoration: const InputDecoration(
                labelText: 'Descrição',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.label_important_outline),
              ),
              onChanged: (value) {
                widget.controller.campoDescricao = value;
              },
            ),
            const SizedBox(
              height: 20,
            ),
            TextField(
              decoration: const InputDecoration(
                labelText: 'Status',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.label_important_outline),
              ),
              onChanged: (value) {
                widget.controller.campoStatus = value;
              },
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10, right: 20, left: 20),
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    widget.controller.adicionarNovasNotas();
                    Navigator.pop(context);
                  });
                },
                child: const Text('Salvar'),
              ),
            )
          ],
        );
      }),
      // body: Padding(
      //   padding: const EdgeInsets.all(8.0),
      //   child: Column(
      //     children: <Widget>[
      //       Observer(
      //         builder: (_) => _textField(
      //             labelText: "Título",
      //             onChanged: controller.anotacao.changeTitulo),
      //       ),
      //       const SizedBox(
      //         height: 20,
      //       ),
      //       Observer(
      //         builder: (_) => _textField(
      //             labelText: "Descrição",
      //             onChanged: controller.anotacao.changeDescricao),
      //       ),
      //       const SizedBox(
      //         height: 20,
      //       ),
      //       Observer(
      //         builder: (_) => _textField(
      //             labelText: "Status",
      //             onChanged: controller.anotacao.changeStatus),
      //       ),
      //       const SizedBox(
      //         height: 40,
      //       ),
      //       Observer(builder: (_) {
      //         return ElevatedButton(
      //           onPressed: () {},
      //           child: const Text("Salvar"),
      //         );
      //       })
      //     ],
      //   ),
      // ),
      // body: Form(
      //   key: _form,
      //   child: Column(
      //     children: [
      //       Padding(
      //         padding: const EdgeInsets.all(10.0),
      //         child: Column(
      //           children: [
      //             Padding(
      //               padding: const EdgeInsets.only(top: 5),
      //               child: TextFormField(
      //                 controller: _titulo,
      //                 decoration: const InputDecoration(
      //                   labelText: 'Título',
      //                   border: OutlineInputBorder(),
      //                   prefixIcon: Icon(Icons.label_important_outline),
      //                 ),
      //                 validator: (value) {
      //                   if (value!.isEmpty) {
      //                     return 'Informe o título.';
      //                   }
      //                   return null;
      //                 },
      //                 // onChanged: (text) {
      //                 //   titulo = text;
      //                 // },
      //               ),
      //             ),
      //             Padding(
      //               padding: const EdgeInsets.only(top: 8),
      //               child: TextFormField(
      //                 controller: _descricao,
      //                 decoration: const InputDecoration(
      //                   labelText: 'Descrição',
      //                   border: OutlineInputBorder(),
      //                   prefixIcon: Icon(Icons.format_list_bulleted_outlined),
      //                 ),
      //                 validator: (value) {
      //                   if (value!.isEmpty) {
      //                     return 'Informe a descrição.';
      //                   }
      //                   return null;
      //                 },
      //                 // onChanged: (text) {
      //                 //   descricao = text;
      //                 // },
      //               ),
      //             ),
      //             Padding(
      //               padding: const EdgeInsets.only(top: 8),
      //               child: TextFormField(
      //                 controller: _status,
      //                 decoration: const InputDecoration(
      //                   labelText: 'Status',
      //                   border: OutlineInputBorder(),
      //                   prefixIcon: Icon(Icons.check_circle_outline_rounded),
      //                 ),
      //                 validator: (value) {
      //                   if (value!.isEmpty) {
      //                     return 'Informe o status.';
      //                   }
      //                   return null;
      //                 },
      //                 // onChanged: (text) {
      //                 //   status = text;
      //                 // },
      //               ),
      //             ),
      //             Padding(
      //               padding:
      //                   const EdgeInsets.only(top: 10, right: 20, left: 20),
      //               child: ElevatedButton(
      //                 onPressed: salvarAnotacao,
      //                 child: const Text("Salvar"),
      //               ),
      //             ),
      //           ],
      //         ),
      //       ),
      //     ],
      //   ),
      // ),
    );
  }
}
